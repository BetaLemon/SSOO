#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>
#include <wait.h>
#include <stdio.h>
#include <iostream>
//#include <SFML/Graphics.hpp>

// EJERCICIO 18

int ppRP[2], ppPG[2];

sf::Vector2i posRaton;
sf::Vector2i posGato[4];

int main(){
    pipe(ppRP);
    pipe(ppPG);
    pid_t pid = fork();
    if(pid == 0){
        // Ratón
        int pos[2] = {3,6}; // o lo que capturaramos del mouse      posRaton.x;posRaton.y
        write(ppRP[1], pos, 2*sizeof(int));
        exit(0);
    }
    else{
        pid = fork();
        if(pid == 0){ // !!!!!!!!!!!!!!!!!
            // Gato
            int pos[2];
            read(ppPG[0], pos, 2*sizeof(int));
            posRaton.x = pos[0];
            posRaton.y = pos[1];
            std::cout << "Gato recibe: " << posRaton.x << " " << posRaton.y << std::endl;
        }
        else{
        // Padre
            int pos[2];
            read(ppRP[0], pos, 2*sizeof(int));
            write(ppPG[1], pos, 2*sizeof(int));
            // wait (porque el padre tiene que esperar a que los hijos acaben.
        }
    }
}
