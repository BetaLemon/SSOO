#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>
#include <wait.h>
#include <stdio.h>
#include <iostream>
//#include <SFML/Graphics.hpp>

//COMUNICACIÓN HIJO A PADRE y luego del Padre al Hijo

int fd[2];  // Hijo -> Padre
int fd2[2]; // Padre -> Hijo
bool turno;

void LeerPadre(int _sig){
    int buff[2];
    size_t s = read(fd[0], buff, 2*sizeof(int));
    std::cout << "[0] " << buff[0] << ", [1] " << buff[1] << std::endl;
    // EL PADRE CONTESTA AL HIJO:
    write(fd2[1], "abc", 3*sizeof(char));
    kill(0, SIGUSR1);
}

void LeerHijo(int _sig){
    char texto[3];
    // EL HIJO RECIBE LA RESPUESTA DEL PAE:
    size_t s = read(fd2[0], texto, 3*sizeof(char));
    std::cout << "Texto: " << texto << std::endl;
}

int main2(){
    int ok = pipe(fd);  // Hijo envía al padre
    ok = pipe(fd2);     // Padre envía al hijo
    signal(SIGUSR1, LeerPadre);
    pid_t pid = fork();

    if(pid == 0){
        signal(SIGUSR1, LeerHijo);
        int buf[2] = {3,6};
        write(fd[1], buf, 2*sizeof(int));
        kill(getppid(), SIGUSR1);
        while(1) pause();
    }
    else{
        while(1) pause();
    }
}
